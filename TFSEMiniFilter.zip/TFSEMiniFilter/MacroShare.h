#ifndef __MACROSHARE_H__
#define __MACROSHARE_H__

//	���ܱ�ʶ
#define ENCRYPT_MARK_STRING "Sunlight"

#define ENCRYPT_MARK_STRING_LEN 8

#define SECRET_PROC_NAME "notepad.exe"

//	���ܱ�ʶ����
#define ENCRYPT_MARK_LEN 4096

#define BUFFER_TAG 'sds'
#define ENCRYPT_TAG 'cne'
#define	FLT_CONTEXT_REGISTRATION_TAG 'creg'

#endif